# CodeInjector Pygame Runner

App companion separado para executar no Android scripts e jogos Pygame enviados pela IDE CodeInjector. O package/application ID deve permanecer `org.codeinjector.pygamerunner`, porque a IDE usa esse identificador para abrir o app.

## Build pelo GitHub usando o celular

1. Crie um repositório para o Pygame Runner.
2. Envie **todo o conteúdo** deste ZIP para a raiz. Preserve especialmente `p4a-recipes/pygame-ce/__init__.py`.
3. Abra **Actions → Build APK → Run workflow** ou faça um push.
4. Baixe o artefato `CodeInjector-Pygame-Runner-APK`, extraia o ZIP do artefato e instale o APK no celular.
5. Instale também o CodeInjector IDE. Quando um script com import Pygame for executado, a IDE enviará os arquivos do projeto ao runner.

## Limitação importante

O recipe local `pygame-ce` é experimental e baseado em trabalho comunitário para python-for-android. O workflow tenta compilar Pygame CE com SDL2 no Android arm64, mas o build pode falhar ou algumas APIs nativas podem não funcionar. Isso não afeta o repositório do CodeInjector IDE nem o Kivy Runner, pois são builds separados.

As dependências adicionais do projeto precisam ser implementadas como receitas de python-for-android quando contêm extensões nativas e, em seguida, adicionadas à lista `requirements`. O workflow compila no GitHub Actions e precisa de testes reais no aparelho.
