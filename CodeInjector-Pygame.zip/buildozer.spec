[app]
title = CodeInjector Pygame Runner
package.name = pygamerunner
package.domain = org.codeinjector
source.dir = .
source.include_exts = py,png,jpg,jpeg,bmp,ttf,otf,wav,ogg,mp3,json,txt
version = 1.0.0
requirements = python3,pygame-ce,pyjnius
orientation = landscape
fullscreen = 0
android.minapi = 24
android.archs = arm64-v8a
android.accept_sdk_license = True
p4a.bootstrap = sdl2
p4a.local_recipes = p4a-recipes

[buildozer]
log_level = 2
warn_on_root = 1
