"""CodeInjector Pygame Runner.

Recebe um ZIP da IDE por URI content://, extrai os arquivos e executa o
script selecionado no Python/Pygame compilado para Android via SDL2.
"""
__version__ = "1.0.0"

import json
import os
from pathlib import Path, PurePosixPath
import runpy
import shutil
import sys
import textwrap
import traceback
import zipfile

EXTRA_PROJECT_URI = "org.codeinjector.runner.PROJECT_URI"
MANIFEST_PATH = "__codeinjector__/manifest.json"
MAX_ARCHIVE_BYTES = 64 * 1024 * 1024
MAX_UNPACKED_BYTES = 96 * 1024 * 1024
MAX_ARCHIVE_FILES = 500


def _android_activity():
    try:
        from jnius import autoclass
        return autoclass("org.kivy.android.PythonActivity").mActivity
    except Exception:
        return None


def _read_shared_archive(destination: Path) -> bool:
    activity = _android_activity()
    if activity is None:
        return False
    stream = None
    try:
        intent = activity.getIntent()
        uri = intent.getData()
        if uri is None:
            raw = intent.getStringExtra(EXTRA_PROJECT_URI)
            if raw:
                from jnius import autoclass
                uri = autoclass("android.net.Uri").parse(str(raw))
        if uri is None:
            return False

        from array import array
        from jnius import autoclass
        ByteArrayOutputStream = autoclass("java.io.ByteArrayOutputStream")
        stream = activity.getContentResolver().openInputStream(uri)
        if stream is None:
            raise RuntimeError("O Android não conseguiu abrir o arquivo compartilhado pela IDE.")
        output = ByteArrayOutputStream()
        buffer = array("b", [0] * 16384)
        total = 0
        while True:
            count = stream.read(buffer, 0, len(buffer))
            if count < 0:
                break
            total += count
            if total > MAX_ARCHIVE_BYTES:
                raise RuntimeError("O projeto compartilhado passou de 64 MB.")
            output.write(buffer, 0, count)
        destination.write_bytes(str(output.toString("ISO-8859-1")).encode("latin-1"))
        return True
    finally:
        if stream is not None:
            try:
                stream.close()
            except Exception:
                pass


def _safe_extract(archive_path: Path, destination: Path) -> Path:
    if destination.exists():
        shutil.rmtree(destination, ignore_errors=True)
    destination.mkdir(parents=True, exist_ok=True)
    root = destination.resolve()
    unpacked = 0
    entries = 0
    with zipfile.ZipFile(str(archive_path), "r") as archive:
        for info in archive.infolist():
            if info.is_dir():
                continue
            name = info.filename.replace("\\", "/")
            parsed = PurePosixPath(name)
            if parsed.is_absolute() or not parsed.parts or any(part in ("", ".", "..") for part in parsed.parts):
                raise RuntimeError("O ZIP contém um caminho de arquivo inválido.")
            target = (destination / Path(*parsed.parts)).resolve()
            if target != root and root not in target.parents:
                raise RuntimeError("O ZIP tenta gravar fora da pasta do projeto.")
            entries += 1
            unpacked += info.file_size
            if entries > MAX_ARCHIVE_FILES or unpacked > MAX_UNPACKED_BYTES:
                raise RuntimeError("O projeto é muito grande para ser aberto no runner.")
            target.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(info, "r") as src, open(target, "wb") as dst:
                shutil.copyfileobj(src, dst, length=64 * 1024)
    return destination


def _load_project():
    activity = _android_activity()
    files_dir = Path(str(activity.getFilesDir().getAbsolutePath())) if activity is not None else Path.cwd()
    files_dir.mkdir(parents=True, exist_ok=True)
    archive_path = files_dir / "codeinjector-project.zip"
    if not _read_shared_archive(archive_path):
        return None, None
    project_dir = files_dir / "codeinjector-project"
    _safe_extract(archive_path, project_dir)
    archive_path.unlink(missing_ok=True)
    manifest_file = project_dir / MANIFEST_PATH
    if not manifest_file.is_file():
        raise RuntimeError("O pacote enviado pela IDE não contém o manifesto do projeto.")
    manifest = json.loads(manifest_file.read_text(encoding="utf-8"))
    entry = PurePosixPath(str(manifest.get("entry", "main.py")))
    if entry.is_absolute() or any(part in ("", ".", "..") for part in entry.parts):
        raise RuntimeError("O arquivo de entrada do projeto não é válido.")
    script = (project_dir / Path(*entry.parts)).resolve()
    if project_dir.resolve() not in script.parents or not script.is_file():
        raise RuntimeError("Não encontrei o arquivo Python selecionado no projeto.")
    return project_dir, script


def _show_message(title, message):
    import pygame
    pygame.init()
    screen = pygame.display.set_mode((800, 480), pygame.RESIZABLE)
    pygame.display.set_caption(title)
    font = pygame.font.Font(None, 24)
    small = pygame.font.Font(None, 19)
    clock = pygame.time.Clock()
    running = True
    lines = []
    max_chars = 65
    for paragraph in str(message).splitlines() or [""]:
        if not paragraph:
            lines.append("")
        else:
            lines.extend(textwrap.wrap(paragraph, width=max_chars, replace_whitespace=False) or [""])
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT or (event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE):
                running = False
        screen.fill((17, 22, 35))
        header = font.render(title, True, (116, 190, 255))
        screen.blit(header, (20, 18))
        y = 62
        for line in lines[:max(1, (screen.get_height() - 80) // 24)]:
            screen.blit(small.render(line[:110], True, (230, 235, 245)), (20, y))
            y += 23
        pygame.display.flip()
        clock.tick(30)
    pygame.quit()


def main():
    activity = _android_activity()
    try:
        project_dir, script = _load_project()
        if script is None:
            _show_message(
                "CodeInjector Pygame Runner",
                "Este é o app companion de Pygame.\n\n"
                "Abra um arquivo Python que importe pygame no CodeInjector e toque em Executar.\n\n"
                "O editor envia uma cópia do projeto e este app executa o arquivo selecionado.",
            )
            if activity is not None:
                activity.finish()
            return
        os.chdir(str(project_dir))
        sys.path.insert(0, str(project_dir))
        sys.path.insert(0, str(script.parent))
        print("[CodeInjector Pygame Runner] Executando:", script)
        runpy.run_path(str(script), run_name="__main__")
        print("[CodeInjector Pygame Runner] Script encerrado.")
        if activity is not None:
            activity.finish()
    except BaseException:
        detail = traceback.format_exc()
        print("[CodeInjector Pygame Runner] Falha ao executar o script:\n" + detail)
        try:
            _show_message("Erro no projeto Pygame", detail[-12000:])
        except BaseException:
            traceback.print_exc()


if __name__ == "__main__":
    main()
